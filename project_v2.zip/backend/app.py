from flask import Flask, request, jsonify, session
from flask_cors import CORS
from datetime import datetime
import logging
import json
import sqlite3
import os

# Import advanced modules
from ai.intent_classifier import IntentClassifier
from ai.semantic_analyzer import SemanticAnalyzer
from ai.response_generator import ResponseGenerator
from ai.conversation_memory import ConversationMemory
from ai.sentiment_analyzer import SentimentAnalyzer
from ai.response_database import get_contextual_response

# Try to import user data training
try:
    from train_comprehensive import add_user_entry, USER_DATA_PATH
    USER_TRAINING_AVAILABLE = True
except Exception:
    USER_TRAINING_AVAILABLE = False

# Try to import chatbot.get_response; fall back to simple retriever if unavailable
try:
    from chatbot import get_response as get_chatter_response
    CHATTER_AVAILABLE = True
except Exception:
    get_chatter_response = None
    CHATTER_AVAILABLE = False

from ai.simple_retriever import load_retriever, retrieve

app = Flask(__name__)
CORS(app)
app.secret_key = 'nlp_chatbot_secret_key_2025'

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Database initialization
DB_PATH = 'conversations.db'

def init_db():
    """Initialize conversation database"""
    if not os.path.exists(DB_PATH):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''
            CREATE TABLE conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_message TEXT,
                bot_response TEXT,
                sentiment TEXT,
                intent TEXT,
                confidence REAL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()
        conn.close()
        logger.info("Database initialized")

# Initialize database
init_db()

# Function to save user data for daily training
def save_user_contribution(user_message: str, bot_response: str):
    """Save user-bot conversation for model improvement"""
    try:
        if USER_TRAINING_AVAILABLE and user_message and bot_response:
            if add_user_entry(user_message, bot_response):
                logger.info(f"User contribution saved: '{user_message[:50]}'")
    except Exception as e:
        logger.warning(f"Could not save user contribution: {e}")# Initialize AI modules
intent_classifier = IntentClassifier()
semantic_analyzer = SemanticAnalyzer()
response_generator = ResponseGenerator(confidence_threshold=0.7)
conversation_memory = ConversationMemory(max_history=10)
sentiment_analyzer = SentimentAnalyzer()

# Load retriever model (fallback)
RETRIEVER_MODEL = load_retriever()

@app.route("/chat", methods=["POST"])
def chat():
    """Advanced chat endpoint with sentiment analysis and personalization"""
    try:
        user_message = request.json.get("message", "").strip()
        
        # Validate input
        if not user_message:
            return jsonify({
                "reply": "Please type something.",
                "confidence": 0.0,
                "intent": "empty",
                "sentiment": "neutral",
                "metadata": {}
            }), 400
        
        if len(user_message) > 500:
            return jsonify({
                "reply": "Your message is too long. Please keep it under 500 characters.",
                "confidence": 0.0,
                "intent": "error",
                "sentiment": "neutral",
                "metadata": {}
            }), 400
        
        logger.info(f"User: {user_message}")
        
        # 1. Sentiment Analysis
        sentiment, sentiment_confidence = sentiment_analyzer.analyze(user_message)
        logger.info(f"Sentiment: {sentiment} ({sentiment_confidence:.2f})")
        
        # 2. Classify intent
        intent, intent_confidence = intent_classifier.classify(user_message)
        logger.info(f"Intent: {intent} ({intent_confidence:.2f})")
        
        # 3. Get contextual response based on sentiment and intent
        reply = get_contextual_response(intent, sentiment, user_message)
        confidence = min(intent_confidence, sentiment_confidence)

        # If reply is empty or low-confidence, use fallback retriever or ChatterBot
        if (not reply or len(reply.strip()) < 2) or confidence < 0.3:
            # Try lightweight retriever FIRST for better match
            try:
                retriever_resp, score = retrieve(user_message, model=RETRIEVER_MODEL)
                if retriever_resp and score > 0.1:
                    reply = retriever_resp
                    confidence = max(confidence, float(score))
                    logger.info(f"Retriever matched with score: {score}")
            except Exception as ret_error:
                logger.warning(f"Retriever error: {ret_error}")

            # Try ChatterBot if retriever didn't match well
            if (not reply or len(reply.strip()) < 2 or confidence < 0.2) and CHATTER_AVAILABLE and get_chatter_response:
                try:
                    cb_reply = get_chatter_response(user_message)
                    if cb_reply and len(cb_reply.strip()) > 1:
                        reply = cb_reply
                        confidence = max(confidence, 0.5)
                except Exception:
                    pass
        
        # If still no good response, provide intelligent fallback based on input characteristics
        if not reply or len(reply.strip()) < 2:
            # Check if it's likely a typo or unclear input
            if len(user_message.split()) <= 2 or confidence < 0.2:
                reply = "I'm not entirely sure I understood that correctly. Could you rephrase or provide more context?"
            else:
                reply = "That's an interesting statement! Could you tell me a bit more about what you mean?"
            confidence = 0.3
        
        # 4. Extract user name
        conversation_memory.extract_user_name(user_message)
        
        # 5. Personalize response
        reply = conversation_memory.personalize_response(reply)
        
        # 6. Store in conversation memory
        conversation_memory.add_exchange(user_message, reply, {
            'intent': intent,
            'sentiment': sentiment,
            'intent_confidence': intent_confidence,
            'sentiment_confidence': sentiment_confidence,
            'response_confidence': confidence
        })
        
        # 7. Extract keywords
        keywords = semantic_analyzer.extract_keywords(user_message)
        
        # 8. Save user contribution for daily training (if quality is good)
        if confidence > 0.3 and len(reply.strip()) > 10:
            save_user_contribution(user_message, reply)
        
        # 9. Store in database
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute('''
                INSERT INTO conversations 
                (user_message, bot_response, sentiment, intent, confidence)
                VALUES (?, ?, ?, ?, ?)
            ''', (user_message, reply, sentiment, intent, confidence))
            conn.commit()
            conn.close()
        except Exception as db_error:
            logger.warning(f"Database error: {db_error}")
        
        response_data = {
            "reply": reply,
            "confidence": round(confidence, 3),
            "intent": intent,
            "sentiment": sentiment,
            "emoji": sentiment_analyzer.get_emoji(sentiment),
            "metadata": {
                "user_name": conversation_memory.user_name,
                "keywords": keywords[:5],  # Top 5 keywords
                "intent_confidence": round(intent_confidence, 3),
                "sentiment_confidence": round(sentiment_confidence, 3),
                "sentiment_emoji": sentiment_analyzer.get_emoji(sentiment),
                "timestamp": datetime.now().isoformat()
            }
        }
        
        logger.info(f"Bot: {reply}")
        return jsonify(response_data), 200
        
    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}")
        return jsonify({
            "reply": "I encountered an error. Please try again.",
            "confidence": 0.0,
            "intent": "error",
            "sentiment": "neutral",
            "error": str(e),
            "metadata": {}
        }), 500

@app.route("/conversation-summary", methods=["GET"])
def get_conversation_summary():
    """Get summary of current conversation"""
    try:
        summary = conversation_memory.get_conversation_summary()
        return jsonify(summary), 200
    except Exception as e:
        logger.error(f"Error getting conversation summary: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/reset-conversation", methods=["POST"])
def reset_conversation():
    """Reset conversation history"""
    try:
        conversation_memory.clear_history()
        return jsonify({"message": "Conversation history cleared"}), 200
    except Exception as e:
        logger.error(f"Error resetting conversation: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/save-conversation", methods=["POST"])
def save_conversation():
    """Save conversation JSON to disk and return a download link"""
    try:
        payload = request.get_json() or {}
        conv = payload.get("conversation") or payload.get("conversation_history") or []
        if not conv:
            return jsonify({"error": "No conversation provided"}), 400

        # Ensure folder exists
        out_dir = os.path.join(os.getcwd(), "saved_conversations")
        os.makedirs(out_dir, exist_ok=True)

        filename = f"conversation-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
        path = os.path.join(out_dir, filename)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(conv, f, ensure_ascii=False, indent=2)

        download_url = f"/saved_conversations/{filename}"
        return jsonify({"filename": filename, "download_url": download_url}), 200
    except Exception as e:
        logger.error(f"Error saving conversation: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/analytics", methods=["GET"])
def get_analytics():
    """Get conversation analytics"""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        c.execute("SELECT COUNT(*) FROM conversations")
        total_conversations = c.fetchone()[0]
        
        c.execute("SELECT sentiment, COUNT(*) FROM conversations GROUP BY sentiment")
        sentiment_stats = dict(c.fetchall())
        
        c.execute("SELECT intent, COUNT(*) FROM conversations GROUP BY intent")
        intent_stats = dict(c.fetchall())
        
        conn.close()
        
        return jsonify({
            "total_conversations": total_conversations,
            "sentiment_distribution": sentiment_stats,
            "intent_distribution": intent_stats,
            "timestamp": datetime.now().isoformat()
        }), 200
    except Exception as e:
        logger.error(f"Error getting analytics: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/retrain", methods=["POST"])
def retrain_model():
    """Retrain the model with user-contributed data"""
    try:
        from train_comprehensive import train_comprehensive_model
        
        logger.info("Starting model retraining with user data...")
        model = train_comprehensive_model()
        
        # Reload the retriever in memory
        global RETRIEVER_MODEL
        RETRIEVER_MODEL = load_retriever()
        
        return jsonify({
            "status": "success",
            "message": "Model retrained successfully",
            "total_entries": model['num_entries'],
            "timestamp": datetime.now().isoformat()
        }), 200
    except Exception as e:
        logger.error(f"Error retraining model: {str(e)}")
        return jsonify({
            "status": "error",
            "message": f"Retraining failed: {str(e)}"
        }), 500

@app.route("/training-status", methods=["GET"])
def training_status():
    """Get information about the current model and training data"""
    try:
        user_data_count = 0
        if os.path.exists('user_training_data.json'):
            with open('user_training_data.json', 'r', encoding='utf-8') as f:
                user_data = json.load(f)
                user_data_count = len(user_data) if isinstance(user_data, list) else 0
        
        return jsonify({
            "model_entries": RETRIEVER_MODEL.get('num_entries', 0),
            "user_contributed_entries": user_data_count,
            "training_logs": "training_logs.json",
            "model_path": "ai/simple_retriever.json",
            "timestamp": datetime.now().isoformat()
        }), 200
    except Exception as e:
        logger.error(f"Error getting training status: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route("/", methods=["GET"])
def health_check():
    """Health check endpoint with feature information"""
    return jsonify({
        "status": "AI Chatbot Backend Running",
        "version": "2.0.0",
        "features": [
            "Sentiment Analysis",
            "Intent Classification",
            "Conversation Memory",
            "Response Generation",
            "Semantic Understanding",
            "User Personalization",
            "Conversation Logging",
            "Analytics Tracking",
            "Daily User Training",
            "Comprehensive Knowledge Base"
        ],
        "endpoints": {
            "/chat": "POST - Send message",
            "/conversation-summary": "GET - Get chat summary",
            "/reset-conversation": "POST - Clear history",
            "/analytics": "GET - View analytics",
            "/retrain": "POST - Retrain with user data",
            "/training-status": "GET - Get training info",
            "/": "GET - Health check"
        },
        "timestamp": datetime.now().isoformat()
    }), 200

@app.errorhandler(400)
def bad_request(error):
    return jsonify({"error": "Bad request"}), 400

@app.errorhandler(500)
def server_error(error):
    return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    # Serve saved_conversations statically
    from flask import send_from_directory

    @app.route('/saved_conversations/<path:filename>')
    def serve_saved(filename):
        return send_from_directory(os.path.join(os.getcwd(), 'saved_conversations'), filename)

    app.run(debug=False, port=5000)
