let conversations = {},
  currentGuest = "Guest 1",
  guestCounter = 1;
const messagesContainer = document.getElementById("messagesContainer"),
  userInput = document.getElementById("userInput"),
  charCount = document.getElementById("charCount"),
  sendBtn = document.getElementById("sendBtn"),
  clearBtn = document.getElementById("clearBtn"),
  saveBtn = document.getElementById("saveBtn"),
  downloadBtn = document.getElementById("downloadBtn"),
  newChatBtn = document.getElementById("newChatBtn"),
  historyList = document.getElementById("chatHistoryList"),
  currentGuestName = document.getElementById("currentGuestName"),
  chatTitle = document.getElementById("chatTitle"),
  statusIndicator = document.getElementById("statusIndicator"),
  statusText = document.getElementById("statusText");
function loadConversations() {
  const e = localStorage.getItem("chatbot_conversations");
  e ? (conversations = JSON.parse(e)) : initializeGuest();
}
function initializeGuest() {
  conversations[currentGuest] ||
    (conversations[currentGuest] = {
      name: currentGuest,
      messages: [],
      createdAt: new Date().toISOString(),
    });
}
function saveConversations() {
  (localStorage.setItem("chatbot_conversations", JSON.stringify(conversations)),
    showToast("Saved!"));
}
function addMessageToConversation(e, s) {
  (conversations[currentGuest] || initializeGuest(),
    conversations[currentGuest].messages.push({
      sender: e,
      text: s,
      timestamp: new Date().toISOString(),
    }),
    saveConversations());
}
function addMessage(e, s) {
  const t = document.getElementById("welcomeMessage");
  t && t.remove();
  const o = document.createElement("div");
  ((o.className = `message ${s}`),
    (o.innerHTML = `<div class="message-content">${(e = "" + e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;")}</div>`),
    messagesContainer.appendChild(o),
    (messagesContainer.scrollTop = messagesContainer.scrollHeight));
}
function showTypingIndicator() {
  const e = document.createElement("div");
  ((e.className = "message bot"),
    (e.id = "typingIndicator"),
    (e.innerHTML =
      '<div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div>'),
    messagesContainer.appendChild(e),
    (messagesContainer.scrollTop = messagesContainer.scrollHeight));
}
function removeTypingIndicator() {
  const e = document.getElementById("typingIndicator");
  e && e.remove();
}
async function sendMessage(e = null) {
  const s = e || userInput.value.trim();
  if (!s) return;
  (addMessage(s, "user"),
    addMessageToConversation("user", s),
    (userInput.value = ""),
    (charCount.textContent = "0"),
    (sendBtn.disabled = !0),
    (userInput.disabled = !0),
    showTypingIndicator(),
    updateStatus("Thinking...", !1));
  try {
    const e = await fetch("http://127.0.0.1:5000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: s }),
    });
    if ((removeTypingIndicator(), e.ok)) {
      const t = await e.json();
      (addMessage(t.reply || "No response", "bot"),
        addMessageToConversation("bot", t.reply || "No response"),
        updateStatus("Ready", !0));
    } else (addMessage("Error. Try again.", "bot"), updateStatus("Error", !1));
  } catch (e) {
    (removeTypingIndicator(),
      console.error(e),
      addMessage("Cannot connect to server (http://127.0.0.1:5000)", "bot"),
      updateStatus("Error", !1));
  }
  ((sendBtn.disabled = !1), (userInput.disabled = !1), userInput.focus());
}
function updateStatus(e, s) {
  ((statusText.textContent = e),
    (statusIndicator.style.color = s ? "#4ade80" : "#ef4444"));
}
function clearConversation() {
  conversations[currentGuest] &&
    conversations[currentGuest].messages.length > 0 &&
    confirm("Clear conversation?") &&
    ((conversations[currentGuest].messages = []),
    saveConversations(),
    (messagesContainer.innerHTML =
      '<div class="welcome-message" id="welcomeMessage"><div class="welcome-icon"><i class="fas fa-robot"></i></div><h2>Chat</h2><p>Ask anything!</p></div>'),
    showToast("✓ Cleared"));
}
async function saveConversationToBackend() {
  const e = conversations[currentGuest];
  if (!e || 0 === e.messages.length) return void showToast("No messages");
  try {
    (await fetch("http://127.0.0.1:5000/save-conversation", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        conversation_history: e.messages,
        guest_name: e.name,
      }),
    }),
      showToast("✓ Saved to server!"));
  } catch (s) {
    showToast("✓ Saved locally!");
  }
}
function downloadConversation() {
  const e = conversations[currentGuest];
  if (!e || 0 === e.messages.length) return void showToast("No messages");
  const s = JSON.stringify(e, null, 2),
    t = new Blob([s], { type: "application/json" }),
    o = URL.createObjectURL(t),
    a = document.createElement("a");
  ((a.href = o),
    (a.download = `${e.name}_${new Date().toISOString().slice(0, 10)}.json`),
    document.body.appendChild(a),
    a.click(),
    document.body.removeChild(a),
    URL.revokeObjectURL(o),
    showToast("✓ Downloaded"));
}
function newChat() {
  (guestCounter++,
    (currentGuest = `Guest ${guestCounter}`),
    initializeGuest(),
    updateUI(),
    (messagesContainer.innerHTML =
      '<div class="welcome-message" id="welcomeMessage"><div class="welcome-icon"><i class="fas fa-robot"></i></div><h2>Chat</h2><p>Ask anything!</p></div>'),
    saveConversations(),
    showToast(`✓ ${currentGuest}`));
}
function updateUI() {
  ((currentGuestName.textContent = currentGuest),
    (chatTitle.textContent = currentGuest),
    (historyList.innerHTML = ""),
    Object.entries(conversations).forEach(([e, s]) => {
      const t = document.createElement("div");
      ((t.className = `history-item ${e === currentGuest ? "active" : ""}`),
        (t.textContent = s.name),
        (t.onclick = () => switchConversation(e)),
        historyList.appendChild(t));
    }));
  const e = conversations[currentGuest];
  ((messagesContainer.innerHTML = ""),
    e && e.messages.length > 0
      ? e.messages.forEach((e) => {
          addMessage(e.text, e.sender);
        })
      : (messagesContainer.innerHTML =
          '<div class="welcome-message" id="welcomeMessage"><div class="welcome-icon"><i class="fas fa-robot"></i></div><h2>Chat</h2><p>Ask anything!</p></div>'));
}
function switchConversation(e) {
  ((currentGuest = e),
    updateUI(),
    updateStatus("Ready", !0),
    showToast(`Switched to ${e}`));
}
function showToast(e) {
  const s = document.createElement("div");
  ((s.className = "toast"),
    (s.textContent = e),
    document.body.appendChild(s),
    setTimeout(() => {
      s.remove();
    }, 3e3));
}
(sendBtn && sendBtn.addEventListener("click", () => sendMessage()),
  clearBtn &&
    clearBtn.addEventListener("click", () => {
      clearConversation();
    }),
  saveBtn && saveBtn.addEventListener("click", saveConversationToBackend),
  downloadBtn && downloadBtn.addEventListener("click", downloadConversation),
  newChatBtn && newChatBtn.addEventListener("click", newChat),
  userInput.addEventListener("keypress", (e) => {
    "Enter" === e.key && !e.shiftKey && (e.preventDefault(), sendMessage());
  }),
  userInput.addEventListener("input", () => {
    charCount.textContent = userInput.value.length;
  }),
  loadConversations(),
  updateUI(),
  userInput.focus());
