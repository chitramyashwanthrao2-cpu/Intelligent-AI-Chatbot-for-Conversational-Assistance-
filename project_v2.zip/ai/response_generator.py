"""
Response Generator (moved to `ai/`).
"""

from functools import lru_cache
from typing import Tuple
try:
    from chatbot import get_response as get_chatterbot_response
except Exception:
    # ChatterBot may not be available in all environments
    def get_chatterbot_response(text):
        return ""

class ResponseGenerator:
    def __init__(self, confidence_threshold: float = 0.7):
        self.confidence_threshold = confidence_threshold
        self.response_cache = {}
        self.common_responses = {
            'hello': 'Hello! How can I help you today?',
            'hi': 'Hi there! What can I do for you?',
            'hey': 'Hey! Nice to see you!',
            'who are you': 'I\'m an AI chatbot designed to help answer your questions.',
            'what is your name': 'I\'m an AI Assistant chatbot.',
            'bye': 'Goodbye! Have a great day!',
            'goodbye': 'See you later!',
            'thanks': 'You\'re welcome!',
            'thank you': 'Happy to help!',
            'help': 'I can answer questions and have conversations with you!'
        }

    @lru_cache(maxsize=100)
    def get_cached_response(self, user_input: str) -> Tuple[str, float, bool]:
        normalized = user_input.lower().strip()
        if normalized in self.common_responses:
            return self.common_responses[normalized], 0.95, True
        for key, response in self.common_responses.items():
            if key in normalized and len(normalized) < 30:
                return response, 0.85, True
        return "", 0.0, False

    def generate_response(self, user_input: str, confidence: float = None) -> Tuple[str, float]:
        cached_response, cache_confidence, is_cached = self.get_cached_response(user_input)
        if is_cached:
            return cached_response, cache_confidence
        try:
            bot_response = get_chatterbot_response(user_input)
            response_confidence = self._calculate_response_confidence(user_input, bot_response)
            if response_confidence < self.confidence_threshold:
                fallback = "I'm not entirely sure I understood that. Could you rephrase or provide more details?"
                return fallback, response_confidence
            return bot_response, response_confidence
        except Exception:
            return f"I apologize, I'm having trouble processing that. Could you try again?", 0.3

    def _calculate_response_confidence(self, user_input: str, response: str) -> float:
        confidence = 0.5
        if len(response) > 50:
            confidence += 0.2
        words = response.split()
        if len(words) > len(set(words)):
            confidence -= 0.1
        if '?' in user_input:
            confidence += 0.1
        return min(1.0, max(0.1, confidence))

    def handle_low_confidence(self, user_input: str) -> str:
        fallback_responses = [
            "I'm not sure I understood that correctly. Could you rephrase?",
            "Could you provide more details about what you mean?",
            "I'm having trouble understanding. Can you say that differently?",
            "Let me ask for clarification - could you explain that further?"
        ]
        return fallback_responses[hash(user_input) % len(fallback_responses)]
