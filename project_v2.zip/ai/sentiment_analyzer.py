"""
Sentiment Analyzer (moved to `ai/`).
"""

from textblob import TextBlob
import re
from typing import Tuple

class SentimentAnalyzer:
    SENTIMENT_KEYWORDS = {
        'positive': [
            'great', 'good', 'excellent', 'awesome', 'wonderful', 'fantastic', 'amazing',
            'love', 'happy', 'joy', 'pleased', 'satisfied', 'thanks', 'thank you',
            'appreciate', 'brilliant', 'perfect', 'beautiful', 'nice', 'kind', 'helpful'
        ],
        'negative': [
            'bad', 'terrible', 'awful', 'horrible', 'hate', 'dislike', 'angry', 'upset',
            'sad', 'disappointed', 'frustrating', 'annoyed', 'irritated', 'useless',
            'stupid', 'fail', 'waste', 'mistake', 'wrong', 'broken', 'sick', 'tired'
        ],
        'neutral': [
            'ok', 'okay', 'fine', 'alright', 'so-so', 'normal', 'average', 'regular'
        ]
    }

    def __init__(self):
        self.compound_keywords = {
            'very': 1.5,
            'really': 1.3,
            'extremely': 1.6,
            'so': 1.2,
            'not': -1.0,
            'no': -0.8,
            'never': -0.9
        }

    def analyze(self, text: str) -> Tuple[str, float]:
        text_lower = text.lower()
        positive_count = sum(1 for word in self.SENTIMENT_KEYWORDS['positive'] if word in text_lower)
        negative_count = sum(1 for word in self.SENTIMENT_KEYWORDS['negative'] if word in text_lower)
        neutral_count = sum(1 for word in self.SENTIMENT_KEYWORDS['neutral'] if word in text_lower)
        try:
            blob = TextBlob(text)
            polarity = blob.sentiment.polarity
        except Exception:
            polarity = 0
        confidence_boost = self._calculate_confidence_boost(text_lower)
        if positive_count > negative_count:
            sentiment = 'positive'
            confidence = min(1.0, (0.5 + polarity / 2) * confidence_boost)
        elif negative_count > positive_count:
            sentiment = 'negative'
            confidence = min(1.0, (0.5 - polarity / 2) * confidence_boost)
        else:
            sentiment = 'neutral'
            confidence = 0.5 + abs(polarity) * 0.3
        if '?' in text:
            confidence *= 0.8
        return sentiment, max(0.0, min(1.0, confidence))

    def _calculate_confidence_boost(self, text: str) -> float:
        boost = 1.0
        for word, multiplier in self.compound_keywords.items():
            if word in text:
                boost *= multiplier
        if re.search(r'[A-Z]{3,}', text):
            boost *= 1.2
        if re.search(r'[!?]{2,}', text):
            boost *= 1.1
        return boost

    def get_emoji(self, sentiment: str) -> str:
        emoji_map = {'positive': '😊', 'negative': '😞', 'neutral': '😐'}
        return emoji_map.get(sentiment, '😐')

    def get_response_tone(self, sentiment: str) -> str:
        tones = {'positive': 'enthusiastic', 'negative': 'empathetic', 'neutral': 'informative'}
        return tones.get(sentiment, 'friendly')

    def get_suggestion(self, sentiment: str, confidence: float) -> str:
        if sentiment == 'positive' and confidence > 0.7:
            return "That's wonderful! I'm glad you're happy! How can I help further?"
        elif sentiment == 'negative' and confidence > 0.7:
            return "I'm sorry to hear you're unhappy. Let me try to help improve things."
        elif sentiment == 'neutral':
            return "I see. Tell me more about what you'd like to know."
        else:
            return "Thanks for sharing. What else would you like to know?"
