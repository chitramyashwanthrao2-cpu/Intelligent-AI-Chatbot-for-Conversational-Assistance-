"""
Comprehensive training data from multiple domains
This includes diverse topics to make the chatbot more knowledgeable
"""

COMPREHENSIVE_TRAINING_DATA = [
    # === GREETINGS & INTRODUCTIONS ===
    "hello|Hi there! How can I help you today?",
    "hi|Hello! Welcome to our AI chatbot. What brings you here?",
    "hey|Hey! Great to see you. What can I do for you?",
    "good morning|Good morning! I hope you're having a great day. How can I assist?",
    "good afternoon|Good afternoon! What can I help you with?",
    "good evening|Good evening! Glad to see you. How can I help?",
    "greetings|Greetings! I'm here to help with any questions you have.",
    "howdy|Howdy! What brings you here today?",
    
    # === ABOUT THE CHATBOT ===
    "who are you|I'm an advanced AI chatbot designed to have intelligent conversations and help answer your questions with comprehensive responses.",
    "what are you|I'm an artificial intelligence assistant powered by natural language processing and machine learning algorithms.",
    "what is your name|I'm your AI Assistant. I don't have a specific name, but you can think of me as your conversational companion.",
    "introduce yourself|I'm an AI chatbot with advanced capabilities in understanding context, analyzing sentiment, and generating thoughtful responses.",
    "what can you do|I can help with information, answer questions, have meaningful conversations, provide advice, and assist with various topics.",
    "your capabilities|I have natural language understanding, sentiment analysis, intent classification, and contextual response generation.",
    "are you real|I'm a software program, not a human, but I can have real conversations and provide helpful responses.",
    
    # === TECHNOLOGY & PROGRAMMING ===
    "what is python|Python is a high-level programming language known for its simplicity and readability. It's used in web development, data science, machine learning, and automation.",
    "what is ai|AI stands for Artificial Intelligence, which refers to computer systems designed to perform tasks that typically require human intelligence.",
    "what is machine learning|Machine learning is a subset of AI where systems learn from data and improve their performance without being explicitly programmed.",
    "what is deep learning|Deep learning uses neural networks with multiple layers to process complex data and learn sophisticated patterns.",
    "what is nlp|NLP stands for Natural Language Processing, which enables computers to understand and process human language.",
    "what is a database|A database is an organized collection of structured data that can be easily accessed, managed, and updated.",
    "what is javascript|JavaScript is a programming language primarily used for creating interactive web applications and frontend functionality.",
    "what is a framework|A framework is a set of pre-built tools and libraries that help developers build applications more efficiently.",
    
    # === SCIENCE & NATURE ===
    "what is photosynthesis|Photosynthesis is the process by which plants use sunlight, water, and carbon dioxide to produce oxygen and glucose for energy.",
    "what is the solar system|The solar system consists of the sun and all objects that orbit it, including planets, moons, asteroids, and comets.",
    "what are atoms|Atoms are the smallest units of matter made up of protons, neutrons, and electrons.",
    "what is gravity|Gravity is a fundamental force that attracts objects with mass toward each other, keeping us on the ground and planets in orbit.",
    "what is evolution|Evolution is the process by which living organisms change and adapt over time through natural selection.",
    "what are ecosystems|Ecosystems are communities of organisms interacting with their physical environment.",
    
    # === HEALTH & WELLNESS ===
    "how do i stay healthy|To stay healthy, exercise regularly, eat a balanced diet, sleep well, manage stress, and stay hydrated.",
    "what is nutrition|Nutrition refers to the nutrients your body needs to function properly, including proteins, carbohydrates, fats, vitamins, and minerals.",
    "how much water should i drink|Most experts recommend drinking about 8 glasses of water daily, though individual needs may vary.",
    "what is meditation|Meditation is a practice of focusing your mind to achieve mental clarity, relaxation, and emotional balance.",
    "what are vitamins|Vitamins are organic compounds essential for various body functions, growth, and disease prevention.",
    
    # === BUSINESS & CAREER ===
    "what is entrepreneurship|Entrepreneurship is the process of creating and running your own business ventures.",
    "how do i find a job|You can find jobs through job boards, networking, company websites, recruiters, and professional connections.",
    "what is project management|Project management is planning, organizing, and overseeing tasks and resources to achieve specific goals.",
    "what is marketing|Marketing is the process of promoting and selling products or services to target customers.",
    "what makes a good leader|Good leaders communicate effectively, make decisions, inspire others, and take responsibility.",
    "how do i write a resume|A good resume includes your contact info, professional summary, work experience, education, and skills.",
    
    # === EDUCATION & LEARNING ===
    "how do i improve my memory|To improve memory, practice regularly, get adequate sleep, stay mentally active, and use memory techniques.",
    "what is the best way to study|Effective study includes active recall, spaced repetition, understanding concepts, and practicing problems.",
    "how do i learn faster|To learn faster, focus deeply, break information into chunks, teach others, and apply what you learn.",
    "what is critical thinking|Critical thinking is analyzing information objectively to make well-informed decisions.",
    "how do i improve my writing|Improve writing by reading often, practicing regularly, getting feedback, and editing carefully.",
    
    # === ARTS & CREATIVITY ===
    "what is art|Art is human creative expression through visual, performing, or literary means.",
    "how do i draw better|Practice regularly, study anatomy, use references, take courses, and don't be afraid to make mistakes.",
    "what makes a good story|Good stories have compelling characters, clear plots, conflict, resolution, and emotional resonance.",
    "what is music theory|Music theory is the study of how music works, including notes, scales, harmonies, and composition.",
    
    # === TRAVEL & CULTURE ===
    "what should i pack for a trip|Pack essentials like ID, tickets, clothes, toiletries, chargers, medications, and important documents.",
    "how do i stay safe while traveling|Stay aware of surroundings, keep valuables secure, research destinations, use trusted transportation.",
    "what are cultural differences|Cultural differences include variations in customs, beliefs, languages, and social norms between groups.",
    
    # === FOOD & COOKING ===
    "what is cooking|Cooking is preparing food using heat through methods like baking, frying, boiling, or grilling.",
    "how do i cook better|Improve cooking by following recipes, practicing techniques, tasting as you go, and trying new ingredients.",
    "what is a balanced diet|A balanced diet includes appropriate amounts of proteins, carbs, fats, vegetables, and fruits.",
    
    # === SPORTS & FITNESS ===
    "what are the benefits of exercise|Exercise improves physical health, mental wellbeing, energy levels, and prevents diseases.",
    "what is cardio|Cardio is exercise that elevates your heart rate, improving cardiovascular health and endurance.",
    "how do i build muscle|Build muscle through strength training, adequate protein, rest, and consistent progressive overload.",
    
    # === EMOTIONS & RELATIONSHIPS ===
    "how do i make friends|Make friends by joining groups with shared interests, being friendly, listening actively, and staying in touch.",
    "how do i handle stress|Handle stress through exercise, meditation, talking to others, proper sleep, and solving problems.",
    "what is empathy|Empathy is understanding and sharing the feelings of others.",
    "how do i improve my relationships|Improve relationships through communication, listening, trust, respect, and spending quality time.",
    
    # === ENVIRONMENT & SUSTAINABILITY ===
    "what is climate change|Climate change is long-term shifts in global temperatures and weather patterns, largely due to human activities.",
    "how can i be more eco-friendly|Reduce, reuse, recycle, use sustainable products, save water and energy, and support green initiatives.",
    "what is renewable energy|Renewable energy comes from natural sources that replenish, like solar, wind, hydro, and geothermal.",
    
    # === FINANCE & MONEY ===
    "what is budgeting|Budgeting is planning how to spend and save your money to reach financial goals.",
    "how do i save money|Save money by tracking expenses, cutting unnecessary costs, setting savings goals, and automating savings.",
    "what is investing|Investing is putting money into assets like stocks, bonds, or real estate to grow your wealth.",
    "what is cryptocurrency|Cryptocurrency is digital currency using encryption, like Bitcoin and Ethereum.",
    
    # === GETTING HELP ===
    "help|I'm here to help! Feel free to ask me questions about any topic, and I'll provide the most helpful response possible.",
    "can you help me|Of course! I'd be happy to help. Just let me know what you need assistance with.",
    "i need help|No problem! I'm here to assist. What do you need help with?",
    "assist me|Absolutely! I'm available to help with questions, explanations, advice, and much more.",
    
    # === GRATITUDE ===
    "thank you|You're welcome! Happy to help anytime. Is there anything else?",
    "thanks|My pleasure! Feel free to ask me anything else.",
    "appreciate|Glad I could assist! What else can I help you with?",
    "thank you so much|You're very welcome! I'm here to help whenever you need.",
    
    # === AFFIRMATIONS ===
    "yes|Great! Let's proceed with that.",
    "no|I understand. What would you prefer instead?",
    "i agree|Perfect! We're on the same page.",
    "i disagree|That's fair. Could you tell me more about your perspective?",
    
    # === FAREWELLS ===
    "goodbye|Goodbye! It was great talking with you. Feel free to return anytime.",
    "bye|See you later! Have a wonderful day.",
    "see you|Take care! Come back if you need anything.",
    "farewell|Farewell! I enjoyed our conversation. Until next time!",
    "exit|Thanks for chatting with me. Goodbye!",
    
    # === LEARNING & EXPLANATION ===
    "teach me|I'd be happy to teach you! What would you like to learn about?",
    "explain|I'll do my best to explain. Can you be more specific about what you'd like to know?",
    "how do i|That's a great question! Here's how you can approach it...",
    "tell me about|I'd love to tell you about that. Let me provide some useful information.",
    "what does it mean|That's a good question! Let me explain what that means.",
    
    # === PROBLEM SOLVING ===
    "i have a problem|I'm sorry to hear that. Can you tell me more about the problem so I can help?",
    "something is wrong|Let's work through this together. Can you describe what's going wrong?",
    "how can i fix|Here are some steps that might help fix that issue...",
    "what's the solution|Let me think about that. Here are some possible solutions...",
    
    # === SMALL TALK ===
    "how are you|I'm functioning perfectly! Thanks for asking. How are you doing?",
    "how's it going|I'm doing great, thanks for asking! How about you?",
    "what's new|Not much on my end, but I'm interested in what's new with you!",
    "tell me something interesting|Here's something interesting: artificial intelligence is advancing rapidly every day!",
    
    # === AFFECTIVE RESPONSES ===
    "i'm sad|I'm sorry you're feeling that way. Would you like to talk about what's bothering you?",
    "i'm happy|That's wonderful! What's making you so happy?",
    "i'm confused|Don't worry, I can help clarify things. What specifically is confusing?",
    "i'm frustrated|I understand. Frustration is normal. Let's work through this together.",
    "i'm excited|That's great enthusiasm! What are you excited about?",
]

def get_all_training_data():
    """Return all training data entries"""
    return COMPREHENSIVE_TRAINING_DATA
