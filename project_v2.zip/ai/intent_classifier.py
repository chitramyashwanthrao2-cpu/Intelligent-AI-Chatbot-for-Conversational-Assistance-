"""
Intent Classification Module (moved to `ai/`).
"""

import re
from typing import Tuple

class IntentClassifier:
    def __init__(self):
        self.intents = {
            'greeting': {
                'patterns': [
                    r'\b(hi|hello|hey|greetings|good morning|good afternoon|good evening)\b',
                    r"\b(what's up|how's it going|howdy)\b"
                ],
                'responses': ['Hello! How can I help?', 'Hi there! What can I do for you?', 'Hey! Nice to meet you!']
            },
            'farewell': {
                'patterns': [
                    r'\b(bye|goodbye|see you|farewell|cya|catch you|take care)\b',
                    r'\b(good bye|see you later|until next time|signing off)\b'
                ],
                'responses': ['Goodbye! Have a great day!', 'See you later!', 'Take care!']
            },
            'self_aware': {
                'patterns': [
                    r"\b(who are you|what are you|what is your name|introduce yourself)\b",
                    r"\b(tell me about yourself|what can you do|what are your capabilities)\b",
                    r"\b(your purpose|your role|who am i talking to)\b"
                ],
                'responses': ["I'm an AI chatbot here to help answer your questions!"]
            },
            'gratitude': {
                'patterns': [
                    r"\b(thank you|thanks|appreciate|thank|thnx|thx|much appreciated)\b",
                    r"\b(thanks so much|thank you so much|really appreciate)\b"
                ],
                'responses': ["You're welcome!", 'Happy to help!', 'Glad I could assist!']
            },
            'help': {
                'patterns': [
                    r"\b(help|assist|support|guide|can you help)\b",
                    r"\b(what can you do|how can you help|assist me)\b"
                ],
                'responses': ['I can answer questions, have conversations, and help with information.']
            },
            'question': {
                'patterns': [r'\?$', r"\bwhat\b", r"\bhow\b", r"\bwhy\b", r"\bwhen\b", r"\bwhere\b", r"\bwhich\b", r"\bwho\b"],
                'responses': []
            },
            'statement': {
                'patterns': [r'\.+$', r"\bi\s|i'm\b", r"\bwe\b"],
                'responses': []
            },
            'affirmation': {
                'patterns': [
                    r"\b(yes|yeah|yep|sure|absolutely|definitely|agreed|correct)\b",
                    r"\b(that's right|you got it|i agree)\b"
                ],
                'responses': []
            },
            'negation': {
                'patterns': [
                    r"\b(no|nope|not|neither|never|disagree)\b",
                    r"\b(that's wrong|incorrect|i disagree)\b"
                ],
                'responses': []
            },
            'unknown': {
                'patterns': [],
                'responses': []
            }
        }

    def classify(self, user_input: str) -> Tuple[str, float]:
        user_input = user_input.lower().strip()
        scores = {}
        for intent, data in self.intents.items():
            matches = 0
            for pattern in data['patterns']:
                if re.search(pattern, user_input, re.IGNORECASE):
                    matches += 1
            if matches > 0:
                scores[intent] = matches / len(data['patterns']) if len(data['patterns']) > 0 else 0.5
        
        if scores:
            best_intent = max(scores, key=scores.get)
            confidence = scores[best_intent]
            return best_intent, confidence
        
        # Return 'unknown' for unrecognized input instead of 'question'
        # This will trigger better fallback mechanisms
        return 'unknown', 0.2

    def get_intent_responses(self, intent: str) -> list:
        if intent in self.intents:
            return self.intents[intent]['responses']
        return []
