"""
Conversation Memory (moved to `ai/`).
"""

from typing import List, Dict
from datetime import datetime
from collections import deque

class ConversationMemory:
    def __init__(self, max_history: int = 10):
        self.max_history = max_history
        self.conversation_history = deque(maxlen=max_history)
        self.user_name = None
        self.session_start = datetime.now()

    def add_exchange(self, user_message: str, bot_response: str, metadata: Dict = None):
        exchange = {
            'timestamp': datetime.now(),
            'user_message': user_message,
            'bot_response': bot_response,
            'metadata': metadata or {}
        }
        self.conversation_history.append(exchange)

    def get_context(self, num_turns: int = 3) -> List[str]:
        context = []
        recent = list(self.conversation_history)[-num_turns:]
        for exchange in recent:
            context.append(f"User: {exchange['user_message']}")
            context.append(f"Bot: {exchange['bot_response']}")
        return context

    def extract_user_name(self, user_message: str) -> bool:
        import re
        patterns = [
            r"i'm\s+(\w+)",
            r"my name is\s+(\w+)",
            r"call me\s+(\w+)",
            r"i am\s+(\w+)",
            r"you can call me\s+(\w+)"
        ]
        for pattern in patterns:
            match = re.search(pattern, user_message, re.IGNORECASE)
            if match:
                self.user_name = match.group(1).capitalize()
                return True
        return False

    def personalize_response(self, response: str) -> str:
        if self.user_name:
            if any(word in response.lower() for word in ['hello', 'hi', 'welcome', 'thanks']):
                return f"{response}, {self.user_name}!"
        return response

    def get_conversation_summary(self) -> Dict:
        return {
            'total_exchanges': len(self.conversation_history),
            'session_duration': (datetime.now() - self.session_start).total_seconds(),
            'user_name': self.user_name,
            'recent_topics': self._extract_topics()
        }

    def _extract_topics(self) -> List[str]:
        topics = set()
        for exchange in self.conversation_history:
            user_msg = exchange['user_message'].lower()
            keywords = ['ai', 'chatbot', 'help', 'question', 'answer', 'name', 'hello']
            for keyword in keywords:
                if keyword in user_msg:
                    topics.add(keyword)
        return list(topics)

    def clear_history(self):
        self.conversation_history.clear()
        self.user_name = None
        self.session_start = datetime.now()
