"""
Response database (moved to `ai/`).
"""

ENHANCED_RESPONSES = {
    'greeting': {
        'patterns': ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening'],
        'responses': [
            "Hello! It's great to meet you. How can I assist you today?",
            "Hi there! Welcome. What brings you here today?",
            "Greetings! I'm here to help. What can I do for you?",
            "Hey! Glad to see you. What's on your mind?",
            "Hello! I'm excited to chat with you. How can I help?"
        ]
    },
    'farewell': {
        'patterns': ['bye', 'goodbye', 'see you', 'farewell', 'take care', 'exit', 'quit'],
        'responses': [
            "Goodbye! It was great talking with you. Come back soon!",
            "Take care! Feel free to return if you need anything.",
            "See you later! Have a wonderful day!",
            "Thanks for the conversation. See you next time!",
            "Bye! Don't hesitate to reach out if you need help."
        ]
    },
    'help': {
        'patterns': ['help', 'assist', 'support', 'guide'],
        'responses': [
            "I can help with information, answer questions, have conversations, and provide guidance on various topics!",
            "I'm here to assist! You can ask me about anything, and I'll do my best to help.",
            "Of course! I'm happy to help. What do you need assistance with?",
            "I'm available to help with questions, explanations, advice, and much more!"
        ]
    },
    'gratitude': {
        'patterns': ['thank', 'thanks', 'appreciate', 'grateful'],
        'responses': [
            "You're welcome! Happy to help anytime!",
            "My pleasure! Feel free to ask me anything else.",
            "Glad I could assist! Is there anything else you'd like to know?",
            "Thanks for that! Always happy to lend a hand."
        ]
    },
    'question': {
        'patterns': ['how', 'what', 'why', 'when', 'where', 'which', 'who'],
        'responses': [
            "That's an interesting question! Let me think about that for a moment.",
            "Great question! I'll do my best to provide a helpful answer.",
            "I understand what you're asking. Let me help you with that."
        ]
    },
    'statement': {
        'patterns': ['i think', 'i believe', 'i feel', 'i want', 'i need'],
        'responses': [
            "That's interesting! Tell me more about what you're thinking.",
            "I see. Can you elaborate on that?",
            "That's a good point. How does that make you feel?",
            "I understand. What led you to that conclusion?"
        ]
    },
    'self_aware': {
        'patterns': ['who are you', 'what are you', 'introduce yourself', 'tell me about yourself'],
        'responses': [
            "I'm an advanced AI chatbot designed to have meaningful conversations and help answer your questions. I use natural language processing to understand context and provide intelligent responses!",
            "I'm an artificial intelligence assistant equipped with multiple analytical engines for sentiment analysis, intent recognition, and contextual understanding. How can I assist you?",
            "I'm a sophisticated conversational AI that learns from interactions. I can help with information, advice, creative tasks, and engaging discussions!"
        ]
    },
    'name_request': {
        'patterns': ['what is your name', 'your name', 'who are you called'],
        'responses': [
            "You can call me your AI Assistant! I don't have a specific name, but I'm here to help you with whatever you need.",
            "I'm simply your helpful AI Chatbot! Feel free to think of me as your conversational companion."
        ]
    },
    'capability': {
        'patterns': ['can you', 'are you able', 'do you know', 'can you tell me', 'do you understand'],
        'responses': [
            "I'll certainly try my best! I have capabilities in understanding context, analyzing sentiment, and generating thoughtful responses.",
            "I'll do my best to help! Feel free to ask me anything and I'll provide the most helpful response I can."
        ]
    },
    'affirmation': {
        'patterns': ['yes', 'yeah', 'yep', 'sure', 'absolutely', 'definitely', 'agree'],
        'responses': [
            "Great! I'm glad we're on the same page. What would you like to do next?",
            "Excellent! Let's continue with that then.",
            "Perfect! I appreciate your agreement. What else can I help with?"
        ]
    },
    'negation': {
        'patterns': ['no', 'nope', 'not really', 'disagree', 'dont agree'],
        'responses': [
            "I understand. Could you tell me more about your perspective?",
            "That's fair. What would you prefer instead?",
            "No problem. Let's explore a different angle then."
        ]
    },
    'unclear': {
        'patterns': [],
        'responses': [
            "I'm not entirely sure I understood that correctly. Could you rephrase or provide more context?",
            "That's an interesting statement! Could you elaborate a bit more so I can better understand what you mean?",
            "I want to make sure I understand you correctly. Could you give me a bit more detail or context?",
            "I'm having trouble understanding that one. Could you break it down further or provide an example?",
            "Let me make sure I'm tracking with you. Can you provide a bit more information about what you're referring to?"
        ]
    }
}

def get_best_response(intent: str, sentiment: str = 'neutral') -> str:
    if intent not in ENHANCED_RESPONSES:
        intent = 'unclear'
    responses = ENHANCED_RESPONSES.get(intent, {}).get('responses', [])
    import random
    if not responses:
        return "I'm not sure. Could you clarify?"
    return random.choice(responses)

def get_contextual_response(intent: str, sentiment: str, user_message: str) -> str:
    base_response = get_best_response(intent, sentiment)
    if sentiment == 'negative' and intent != 'issue':
        base_response = "I understand your concern. " + base_response
    elif sentiment == 'positive':
        base_response = base_response.replace("!", "! ✨")
    return base_response
