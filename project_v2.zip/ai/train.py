"""
Training orchestration (moved to `ai/`).
"""
import os
try:
    from chatbot import train_bot
    CHATTERBOT_AVAILABLE = True
except Exception:
    CHATTERBOT_AVAILABLE = False

from ai.simple_retriever import train_retriever

def load_cornell_dataset():
    candidates = [
        os.path.join(os.path.dirname(__file__), '..', 'dataset', 'cornell_movie_dialogs.txt'),
        os.path.join(os.path.dirname(__file__), 'dataset', 'cornell_movie_dialogs.txt'),
        os.path.join(os.getcwd(), 'dataset', 'cornell_movie_dialogs.txt'),
        os.path.join(os.getcwd(), '..', 'dataset', 'cornell_movie_dialogs.txt')
    ]
    for dataset_path in candidates:
        dataset_path = os.path.normpath(dataset_path)
        if os.path.exists(dataset_path):
            with open(dataset_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.readlines()
    print('Warning: Cornell dataset not found in expected locations')
    return []

def create_custom_training_data():
    return [
        'Hello|Hi there!',
        'Hi|Hello! How can I help you?',
        'How are you?|I'm doing great, thanks for asking!',
        # ... (shortened for brevity) ...
    ]

def main():
    print('🚀 Starting Advanced Chatbot Training...')
    cornell_data = load_cornell_dataset()
    custom_data = create_custom_training_data()
    all_data = cornell_data + custom_data
    if not all_data:
        print('⚠️  Warning: No training data found!')
        return
    print(f'✓ Total training samples: {len(all_data)}')
    if CHATTERBOT_AVAILABLE:
        print('- ChatterBot detected: training ChatterBot model...')
        try:
            train_bot(all_data)
        except Exception as e:
            print(f'Warning: ChatterBot training failed: {e}')
    else:
        print('- ChatterBot not available. Skipping ChatterBot training.')
    print('- Training lightweight retriever index...')
    retriever_model = train_retriever(all_data)
    print(f'✓ Retriever trained with {retriever_model.get("num_entries", 0)} entries')
    print('✅ Training completed successfully!')

if __name__ == '__main__':
    main()
