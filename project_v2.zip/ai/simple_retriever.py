"""
Lightweight retriever moved into `ai/` for organization.
"""

import json
import os
import re
from collections import defaultdict

MODEL_PATH = os.path.join(os.path.dirname(__file__), '..', 'simple_retriever.json')

def _tokenize(s):
    s = s.lower()
    s = re.sub(r'[^a-z0-9 ]', ' ', s)
    return [t for t in s.split() if len(t) > 1]

def train_retriever(data_lines, out_path=None):
    index = []
    for line in data_lines:
        if isinstance(line, str) and '|' in line:
            q, a = line.split('|', 1)
            index.append({'q': q.strip(), 'a': a.strip(), 'tokens': _tokenize(q)})
    model = {'entries': index, 'num_entries': len(index)}
    path = out_path or os.path.normpath(os.path.join(os.getcwd(), 'simple_retriever.json'))
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(model, f, ensure_ascii=False, indent=2)
    return model

def load_retriever(path=None):
    path = path or os.path.normpath(os.path.join(os.getcwd(), 'simple_retriever.json'))
    if not os.path.exists(path):
        return {'entries': [], 'num_entries': 0}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {'entries': [], 'num_entries': 0}

def retrieve(query, model=None, top_k=1):
    if model is None:
        model = load_retriever()
    qtokens = _tokenize(query)
    
    # If query is very short or empty, return neutral response
    if len(qtokens) == 0:
        return ("I didn't catch that. Could you rephrase?", 0.0)
    
    results = []
    for e in model.get('entries', []):
        entry_tokens = e.get('tokens', [])
        # Calculate overlap
        overlap = len(set(qtokens) & set(entry_tokens))
        # Also consider Jaccard similarity for better matching
        if overlap > 0 or len(entry_tokens) > 0:
            union = len(set(qtokens) | set(entry_tokens))
            jaccard_sim = overlap / union if union > 0 else 0
            results.append({
                'response': e.get('a'),
                'overlap': overlap,
                'jaccard': jaccard_sim,
                'score': (overlap * 0.6 + jaccard_sim * 100 * 0.4)
            })
    
    if not results:
        return (None, 0)
    
    # Sort by score and return best match
    best = max(results, key=lambda x: x['score'])
    return (best['response'], min(best['score'] / 10, 1.0))
