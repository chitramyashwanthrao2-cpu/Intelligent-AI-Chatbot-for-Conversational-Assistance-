"""
Semantic Analyzer (moved to `ai/`).
"""

import numpy as np
from typing import List, Tuple
try:
    import spacy
except Exception:
    spacy = None

class SemanticAnalyzer:
    def __init__(self):
        try:
            self.nlp = spacy.load("en_core_web_sm") if spacy else None
        except Exception:
            print("Warning: spaCy model not found. Semantic analysis will be limited.")
            self.nlp = None

    def get_vector(self, text: str) -> np.ndarray:
        if not self.nlp:
            return np.zeros(96)
        doc = self.nlp(text)
        return doc.vector

    def calculate_similarity(self, text1: str, text2: str) -> float:
        if not self.nlp:
            return 0.0
        doc1 = self.nlp(text1)
        doc2 = self.nlp(text2)
        similarity = doc1.similarity(doc2)
        return max(0.0, min(1.0, similarity))

    def find_most_similar(self, query: str, candidates: List[str]) -> Tuple[str, float]:
        if not candidates:
            return "", 0.0
        if not self.nlp:
            return candidates[0], 0.5
        similarities = [self.calculate_similarity(query, c) for c in candidates]
        best_idx = int(np.argmax(similarities))
        return candidates[best_idx], similarities[best_idx]

    def extract_keywords(self, text: str, top_n: int = 5) -> List[str]:
        if not self.nlp:
            return text.split()[:top_n]
        doc = self.nlp(text)
        keywords = [token.text for token in doc if token.pos_ in ['NOUN', 'VERB', 'ADJ']]
        return keywords[:top_n]
