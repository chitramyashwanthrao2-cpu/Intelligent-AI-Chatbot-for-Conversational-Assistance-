"""
Preprocessing utilities (moved to `ai/`).
"""

import nltk
import re
try:
    import spacy
except Exception:
    spacy = None

try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

logger = None
try:
    import logging as _logging
    logger = _logging.getLogger(__name__)
except Exception:
    logger = None

try:
    nlp = spacy.load("en_core_web_sm") if spacy else None
except Exception:
    if logger:
        logger.error("spaCy model not found. Run: python -m spacy download en_core_web_sm")
    nlp = None

def preprocess_text(text):
    if not text or not isinstance(text, str):
        return ""
    text = text.lower().strip()
    text = re.sub(r'[^a-zA-Z ]', '', text)
    tokens = nltk.word_tokenize(text)
    if nlp:
        doc = nlp(" ".join(tokens))
        lemmatized = [token.lemma_ for token in doc]
        return " ".join(lemmatized)
    return " ".join(tokens)
